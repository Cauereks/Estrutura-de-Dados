
public class Sniper extends Personagem{

	public Sniper() {
		super();
	}
	
	public void mirar() {
		System.out.println("Mirando no alvo");
	}
	
	public void atacar() {
		System.out.println("puf");
	}

}
