
public class Pistoleiro extends Personagem {

	public Pistoleiro() {
		super();
	}
	
	public void atirar() {
		System.out.println("bang-bang");
	}
	
}
