
public class Personagem {
	private String nome;
	
	public void dizerNome() {
		
	}
	
	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public void atacar() {
		System.out.println("Ataca");
	}
}
